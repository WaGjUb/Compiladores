#include <stdio.h>
#include <stdlib.h>
#include <regex.h>

int main(int argc, char** argv){
	regex_t er;
	regcomp(&er, argv[1], REG_EXTENDED|REG_NOSUB);

	if((regexec(&er, argv[2], 0, NULL, 0)) == 0){
		printf("Casou.\n");
	}
	else{
		printf("Não Casou.\n");
	}

	return 0;
}